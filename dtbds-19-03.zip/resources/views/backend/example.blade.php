@extends('backend/masterbackend')

@section('title')
Tiêu đề admin website
@endsection

@section('content')

@endsection